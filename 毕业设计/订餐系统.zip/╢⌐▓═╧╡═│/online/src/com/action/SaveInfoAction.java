package com.action;

import com.domain.Account;
import com.domain.Signon;
import com.opensymphony.xwork2.ActionSupport;
import com.service.RegisterService;

public class SaveInfoAction extends ActionSupport{
	
	private Signon signon;
	private Account account;
	private String flag;
	
	public String saveInfo(){

		System.out.println(signon.getUserid() + "................"+signon.getPassword());
		
		RegisterService rs = new RegisterService();
			
		signon.setUserid(signon.getUserid());
		signon.setPassword(signon.getPassword());	
		
		account.setUserid(signon.getUserid());			
		account.setEmail(account.getEmail());
		account.setPhone(account.getPhone());

		rs.saveSignon(signon);
		rs.saveAccount(account);
		
		account = new Account();
		account.setUserid(signon.getUserid());

		account = rs.queryAccountById(account);
		
		System.out.println("account:"+account);
		
		if(account != null){
			
			flag = "1";
			return "success";
			
		}else{
			
			flag = "0";
			return "false";
		}

		
	}	//saveInfo
	
	@Override
	public void validate() {
		// TODO Auto-generated method stub
		super.validate();
		
		System.out.println(1111);
		
		if(signon.getUserid().equals("")){
			
			addActionError("�˻�����Ϊ��");
		}
		
		if(signon.getPassword().equals("")){
			
			addActionError("���벻��Ϊ��");
		}
		
		if(account.getEmail().equals("")){
			
			addActionError("���䲻��Ϊ��");
		}
		
		if(account.getPhone().equals("")){
	
			addActionError("�绰����Ϊ��");
		}

	}	//validate
	
	public SaveInfoAction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Signon getSignon() {
		return signon;
	}
	public void setSignon(Signon signon) {
		this.signon = signon;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

}
