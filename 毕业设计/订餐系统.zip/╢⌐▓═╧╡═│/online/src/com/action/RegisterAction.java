package com.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.domain.Account;
import com.domain.Signon;
import com.service.RegisterService;

public class RegisterAction {

	private Signon signon;
	private Account account;
	
	private Integer count;
	
	public String register(){
		
		System.out.println("ע���˺ţ�"+ signon.getUserid());
		
		RegisterService rs = new RegisterService();
		
		signon.setUserid(signon.getUserid());
		
		count = rs.countSignonByUserid(signon);
		
		System.out.println(count);
		
		if(count == 0){
			
			return "success";
		}else{
			
			return "false";
		}
		
	}	//register
	
	public String updateInfo(){
		
		System.out.println("�޸�����");
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		String pwd = signon.getPassword();
		
		String id = (String) session.getAttribute("uid");
		
		RegisterService rs = new RegisterService();

		signon = new Signon();
		
		signon.setUserid(id);
		signon.setPassword(pwd);
		
		System.out.println(signon.getPassword() + "pwd");
		
		rs.updateSignonById(signon);
		
		count = 1;
		
		return "success";
	}	//updateInfo
	
	
	public RegisterAction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Signon getSignon() {
		return signon;
	}
	public void setSignon(Signon signon) {
		this.signon = signon;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

}
