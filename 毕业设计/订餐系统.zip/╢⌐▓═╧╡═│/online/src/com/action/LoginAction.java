package com.action;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.domain.Account;
import com.domain.Admin;
import com.domain.Signon;
import com.service.SignonService;

public class LoginAction {

	private Signon signon;
	
	private int count;

	private String id;
	
	private String logoutid;
	
	private Admin admin;
	
	private Account account;
	
	private List<Account> acclist;
	
	public String login(){
		
		System.out.println(signon.getUserid() + ":::"+ signon.getPassword());
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		SignonService signonService = new SignonService();
		
		signon = new Signon(signon.getUserid(),signon.getPassword());
		
		count = signonService.countSignons(signon);
		
		System.out.println(count);
		
		if(count > 0){
			
			session.setAttribute("uid", signon.getUserid());
			
			System.out.println("��ǰ�û�" + session.getAttribute("uid"));
			
			return "success";	

		}else{
			
			return "false";
		}
		
	}	//login
	
	public String vertify(){
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		if(session.getAttribute("uid") != null){
			
			id = "1";
			
			return "success";
			
		}else{
			id = "0";
			return "false";
		}
		
	}	//vertify
	
	public String logout(){
	
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		session.removeAttribute("uid");
		
		if(session.getAttribute("uid") == null){
			
			return "success";
		}else{
			
			return "false";
		}
		
	}	///logout
	
	public String adminLogin(){
		
		SignonService signonService = new SignonService();
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		admin = new Admin(admin.getUsername(),admin.getPwd());
		
		count = signonService.countAdmins(admin);
		
		if(count > 0){
			
			System.out.println("����Ա��¼�ɹ�");
			
			session.setAttribute("adminstrator", admin.getUsername());
			
			return "success";	

		}else{
			System.out.println("����Ա��¼ʧ��");
			
			return "false";
		}
	}	//adminLogin
	
	public String adminlogout(){
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		session.removeAttribute("adminstrator");
		
		return "success";
		
	}	///adminlogout
	
	public String queryAllUsers(){
		
		SignonService s = new SignonService();
		
		acclist = new ArrayList<Account>();
		
		acclist = s.queryAllUsers();
		
		for(Account a : acclist){
			
			System.out.println(a.getUserid()+"--"+a.getPhone()+"++"+a.getEmail());
		}
		
		return "success";
	}	//queryAllUsers
	public LoginAction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Signon getSignon() {
		return signon;
	}

	public void setSignon(Signon signon) {
		this.signon = signon;
	}


	public int getCount() {
		return count;
	}


	public void setCount(int count) {
		this.count = count;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLogoutid() {
		return logoutid;
	}

	public void setLogoutid(String logoutid) {
		this.logoutid = logoutid;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public List<Account> getAcclist() {
		return acclist;
	}

	public void setAcclist(List<Account> acclist) {
		this.acclist = acclist;
	}
	
}
