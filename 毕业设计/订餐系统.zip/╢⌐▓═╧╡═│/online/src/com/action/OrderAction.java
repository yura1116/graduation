package com.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.domain.Cart;
import com.domain.Item;
import com.domain.ItemAttr;
import com.domain.Lineitem;
import com.domain.LineitemId;
import com.domain.Orders;
import com.domain.Product;
import com.domain.Views;
import com.service.CartService;
import com.service.CategoryService;
import com.service.OrdersService;
import com.service.iface.CartServiceIface;
import com.service.iface.OrdersServiceIface;

public class OrderAction {

	private Orders order;
	private List<Orders> orderlist;
	
	private OrdersServiceIface orderService;
	
	private Item item;
	private List<Item> itemlist;
	
	private CartServiceIface cartService;
	private Cart cart;
	private List<Cart> cartlist;

	private CategoryService categoryServiec;
	private Lineitem lineitem;
	private List<Lineitem> linelist;

	private int begin;
	private int max;
	private Long orderid;
	private Product product;
	private ItemAttr attr;
	private List<ItemAttr> ia;
	
	private Views views;
	private String comment;
	private String status;
	
	public String saveOrder(){
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
			
		String userid = (String) session.getAttribute("uid"); 
		
		order.setUserid(userid);
		
		Date d = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		
		String date = dateFormat.format(d); 
		System.out.println("�µ�ʱ��"+date);

		order.setOrderdate(date);
		
		Double price = (Double) session.getAttribute("smoney");
		order.setTotalprice(price);
		order.setStatus("����������");
	
		order.setUsername(order.getUsername());
		
		String sex = order.getSex();
		
		if(sex == "1"){
			order.setSex("����");
		}else{
			
			order.setSex("Ůʿ");
		}
		
		order.setLoc(order.getLoc());
		order.setTel(order.getTel());
		
		orderService.saveOrders(order);
		
		System.out.println(order.getOrderid());
		
		if(order.getOrderid() != null){
			
			begin = 1;
		}
		
		Long orderid = order.getOrderid();
		session.setAttribute("orderid", orderid);
		
		cart = new Cart();
		cart.setUserid(userid);
		cartlist = cartService.queryCartByUid(cart);
		System.out.println(cartlist);
		
		for(Cart c : cartlist){
			
			item = new Item();
			item.setItemid(c.getItemid());
			item = categoryServiec.queryItemByItemid(item);
			System.out.println("�۸�"+item.getListprice());
			
			lineitem = new Lineitem();
			
			lineitem.setQuantity(c.getQuantity());
			System.out.println("�۸�"+item.getListprice());
			lineitem.setUnitprice(item.getListprice());
			
			LineitemId id = new LineitemId();
			
			order.setOrderid(order.getOrderid());
			id.setOrderid(order.getOrderid());
			
			item = new Item();
			item.setItemid(c.getItemid());
			id.setItemid(item.getItemid());
			
			lineitem.setId(id);
			
			orderService.saveLineitem(lineitem, order, item);
			
		}	//for cart
			
		return "success";
	}	//saveOrder
	
	public String payOrder(){
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
			
		Long orderid = (Long) session.getAttribute("orderid"); 
		String userid = (String) session.getAttribute("uid"); 
		
		order = new Orders();
		order.setOrderid(orderid);
		
		order = orderService.queryOrders(order);
		
		System.out.println(order.getOrderid()+"!!!!!"+order.getUserid());
		
		linelist = orderService.queryLineitem(order);
		
		 ia = new ArrayList<ItemAttr>();
		
		for(Lineitem line : linelist){

			item = new Item();
			item.setItemid(line.getId().getItemid());
			item = categoryServiec.queryItemByItemid(item);

			product = new Product();
			product.setProductid(item.getProductid());
			product = categoryServiec.queryProductById(product);

			attr = new ItemAttr();
			attr.setItem(item);
			attr.setProduct(product);
			attr.setLineitem(line);
			
			ia.add(attr);
			System.out.println(item.getAttr1());
			System.out.println(line.getId().getItemid()+line.getOrderid()+line.getQuantity()+line.getUnitprice());
		}	//for
		
		session.removeAttribute("itemlist");
		
		return "success";
		
	}	//payOrder
	
	public String orderSuccess(){
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();

		String userid = (String) session.getAttribute("uid"); 
		Long orderid = (Long) session.getAttribute("orderid"); 
		
		//�������� ��չ��ﳵ
		cart = new Cart();
		cart.setUserid(userid);
		cartService.delCartById(cart);
		
		order = new Orders();
		order.setOrderid(orderid);
		
		order = orderService.queryOrders(order);
		
		System.out.println(order.getOrderid()+"===="+order.getOrderdate());
		
		linelist = orderService.queryLineitem(order);
		
		 ia = new ArrayList<ItemAttr>();
		
		for(Lineitem line : linelist){

			item = new Item();
			item.setItemid(line.getId().getItemid());
			item = categoryServiec.queryItemByItemid(item);

			product = new Product();
			product.setProductid(item.getProductid());
			product = categoryServiec.queryProductById(product);

			attr = new ItemAttr();
			attr.setItem(item);
			attr.setProduct(product);
			attr.setLineitem(line);
			
			ia.add(attr);
			System.out.println(item.getAttr1());
			System.out.println(line.getId().getItemid()+line.getOrderid()+line.getQuantity()+line.getUnitprice());
		}	//for
		
		
		return "success";
	}//orderSuccess
	
	
	public String queryOrders(){
		
		System.out.println("��ѯ����");
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();		
			
		String userid = (String) session.getAttribute("uid");
		
		order = new Orders();
		order.setUserid(userid);
		
		orderlist = orderService.queryOrdersById(order);
		
		for(Orders or : orderlist){
			System.out.println(or.getOrderid()+" 1 1 "+or.getOrderdate());
			
		}
		
		return "success";
		
	}	//queryOrders
	
	public String queryOrdersByOrderid(){
		
		System.out.println("������"+orderid);
		
		order = new Orders();
		order.setOrderid(orderid);
		
		order = orderService.queryOrders(order);

		System.out.println(order.getOrderid()+":::"+order.getOrderdate());

		linelist = orderService.queryLineitem(order);
		 ia = new ArrayList<ItemAttr>();
		for(Lineitem line : linelist){

			item = new Item();
			item.setItemid(line.getId().getItemid());
			item = categoryServiec.queryItemByItemid(item);
			
			//����Ʒ��
			product = new Product();
			product.setProductid(item.getProductid());
			product = categoryServiec.queryProductById(product);

			attr = new ItemAttr();
			attr.setItem(item);
			attr.setProduct(product);
			attr.setLineitem(line);
			
			ia.add(attr);
			System.out.println(item.getAttr1());
			System.out.println(line.getId().getItemid()+line.getOrderid()+line.getQuantity()+line.getUnitprice());
		}	//for	
		
		return "success";
	}	//queryOrdersByOrderid
	
	public String comment(){
		
		System.out.println("��������"+orderid);
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();		
			
		//String userid = (String) session.getAttribute("uid");
		
		session.setAttribute("oidComm", orderid);
		
		return "success";
	}	//comment
	
	public String saveComment(){
		
		System.out.println("����"+views.getComments());
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();		
			
		String userid = (String) session.getAttribute("uid");
		Long oidComm = (Long) session.getAttribute("oidComm");
		String comment = views.getComments();
		
		views = new Views();
		views.setOrderid(oidComm);
		views.setUserid(userid);
		views.setComments(comment);
		
		orderService.saveComments(views);
		
		begin = 1;
		
		return "success";
	}	//saveComment
	
	public String queryAllOrders(){
		
		orderlist = new ArrayList<Orders>();
		
		orderlist = orderService.queryOrders();
		
		for(Orders o : orderlist){
			
			System.out.println(o.getOrderid()+o.getOrderdate()+o.getLoc());
		}
		
		return "success";
	}	//"queryAllOrders"
	
	public String updateOrder(){
		
		System.out.println("����Ա�����������"+orderid);
		
		order = new Orders();
		order.setOrderid(orderid);
		
		order.setStatus("����������");
		
		orderService.updateOrdersById(order);
		return "success";
	}	//updateOrder
	
	
	public OrderAction() {
		super();
		// TODO Auto-generated constructor stub
		orderService= new OrdersService();
		cartService = new CartService();
		categoryServiec = new CategoryService();
	}

	public Orders getOrder() {
		return order;
	}

	public void setOrder(Orders order) {
		this.order = order;
	}

	public OrdersServiceIface getOrderService() {
		return orderService;
	}

	public void setOrderService(OrdersServiceIface orderService) {
		this.orderService = orderService;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public List<Item> getItemlist() {
		return itemlist;
	}

	public void setItemlist(List<Item> itemlist) {
		this.itemlist = itemlist;
	}

	public CartServiceIface getCartService() {
		return cartService;
	}

	public void setCartService(CartServiceIface cartService) {
		this.cartService = cartService;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public List<Cart> getCartlist() {
		return cartlist;
	}

	public void setCartlist(List<Cart> cartlist) {
		this.cartlist = cartlist;
	}

	public CategoryService getCategoryServiec() {
		return categoryServiec;
	}

	public void setCategoryServiec(CategoryService categoryServiec) {
		this.categoryServiec = categoryServiec;
	}

	public Lineitem getLineitem() {
		return lineitem;
	}

	public void setLineitem(Lineitem lineitem) {
		this.lineitem = lineitem;
	}

	public List<Lineitem> getLinelist() {
		return linelist;
	}

	public void setLinelist(List<Lineitem> linelist) {
		this.linelist = linelist;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public List<Orders> getOrderlist() {
		return orderlist;
	}

	public void setOrderlist(List<Orders> orderlist) {
		this.orderlist = orderlist;
	}

	public int getBegin() {
		return begin;
	}

	public void setBegin(int begin) {
		this.begin = begin;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public Long getOrderid() {
		return orderid;
	}

	public void setOrderid(Long orderid) {
		this.orderid = orderid;
	}

	public ItemAttr getAttr() {
		return attr;
	}

	public void setAttr(ItemAttr attr) {
		this.attr = attr;
	}

	public List<ItemAttr> getIa() {
		return ia;
	}

	public void setIa(List<ItemAttr> ia) {
		this.ia = ia;
	}

	public Views getViews() {
		return views;
	}

	public void setViews(Views views) {
		this.views = views;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
