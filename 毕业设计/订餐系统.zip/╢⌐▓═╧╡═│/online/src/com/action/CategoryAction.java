package com.action;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.domain.Category;
import com.domain.Item;
import com.domain.Product;
import com.domain.Views;
import com.service.CategoryService;

public class CategoryAction {

	private Category category;
	private List<Category> categorylist;
	
	private Product product;
	private List<Product> productlist;
	
	private Item item;
	private List<Item> itemlist;
	
	private String name;
	private String content;
	private int first;
	private String productid;
	
	private String animal;
	
	private String itemid;
	private String attr;
	private String attr1;
	private Double price;
	private List<Views> viewlist;
	
	private Map<String, Item> itemMap;
	
	private String flag;
	private String itemName;
	
	private Double listPrice;
	public String queryCategory(){
		
		System.out.println("category:");
		
		CategoryService cs = new CategoryService();
		
		category = new Category();
		category.setName("Fish");
		
		cs.queryCategoryByName(category);
		
		return "success";
	}	//queryCategory
	
	public String queryProduct(){
		
		
		CategoryService cs = new CategoryService();
		
		product = new Product();
		category = new Category();
		
		if(content != null){
			//��ҳģ����ѯ
			try {
				content = new String(content.getBytes("ISO8859-1"),"UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("content" +content);
			
			category.setContent(content);
			
			category = cs.queryCategoryByContent(category);

			
			System.out.println("category" +category);
			
			if(category == null){
				
				//����Ϊ��
				flag = "û�з��ϵ���������";
				
			}else{
				
				//���ݲ˹�����
				name = category.getCatid();
				System.out.println("�ҼҲ˹�" + name);
				
			}

		}
		
		System.out.println("name" + name);
		product.setCategory(name);

		productlist = new ArrayList<Product>();
		itemlist = new ArrayList<Item>();
		
		item = new Item();
		
		productlist = cs.queryProduct(product);
		
		for(Product p : productlist){
			
			System.out.println("��Ʒ��"+p.getProductid());
			
			item.setProductid(p.getProductid());
			itemlist = cs.queryItemById(item);
			
			for(Item i : itemlist){
				
				System.out.println(i.getItemid()+ i.getAttr1());
			}
		}
		
		return "success";
		
	}	//queryProduct
	
	public String allCategory(){
			
			CategoryService cs = new CategoryService();
			
			categorylist = new ArrayList<Category>();
			
			categorylist = cs.queryCategory();
			
			product = new Product();
			for(Category cate : categorylist){
				
				System.out.println(cate.getCatid() + "==="+cate.getDescn());
				
			}	
			return "success";
			
		}	//allCategory
	
	
	public String queryItems(){
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		CategoryService cs = new CategoryService();
		
		itemlist = new ArrayList<Item>();
		
		itemlist = cs.queryItems();
		
		for(Item i : itemlist){
			
			//System.out.println(i.getItemid()+"==="+i.getAttr1());

		}
		
		return "success";
	}	//queryItems
	
	public String delItem(){
		
		System.out.println("ɾ����Ʒ���"+itemid);
		
		CategoryService cs = new CategoryService();
		
		item = new Item();
		item.setItemid(itemid);
		
		cs.delItemById(item);
		return "success";
	}	//delItem
	
	
	public String queryViews(){
		
		CategoryService cs = new CategoryService();
		
		viewlist = new ArrayList<Views>();
		
		viewlist = cs.queryViews();
		
		for(Views v : viewlist){
			
			System.out.println(v.getUserid()+v.getOrderid()+v.getComments());
		}
		
		
		return "success";
	}	//queryViews
	
	public String updateItem(){
		
		try {
			itemName = new String(itemName.getBytes("ISO8859-1"),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("����Ա�޸���Ʒ��"+itemid +itemName+listPrice );

		CategoryService cs = new CategoryService();
		
		item = new Item();
		item.setItemid(itemid);
		
		item.setListprice(listPrice);
		item.setAttr1(itemName);
		
		cs.updateItemById(item);
		
		return "success";
	}	//updateItem
	
	public String saveItem(){
		String name = item.getAttr1();
		
		try {
			name = new String(name.getBytes("ISO8859-1"),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("����Ա������Ʒ"+name+item.getProductid()+item.getListprice()+item.getAttr2());
		
		CategoryService cs = new CategoryService();
		
		item.setProductid(item.getProductid());
		item.setListprice(item.getListprice());
		item.setAttr1(name);
		item.setAttr2("images/"+item.getAttr2());
		
		System.out.println(item.getProductid()+item.getListprice()+item.getAttr1()+item.getAttr2());
		
		cs.saveItems(item);
		
		return "success";
		
	}	//saveItem
	
	public CategoryAction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Product> getProductlist() {
		return productlist;
	}

	public void setProductlist(List<Product> productlist) {
		this.productlist = productlist;
	}

	public int getFirst() {
		return first;
	}

	public void setFirst(int first) {
		this.first = first;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public List<Item> getItemlist() {
		return itemlist;
	}

	public void setItemlist(List<Item> itemlist) {
		this.itemlist = itemlist;
	}

	public String getProductid() {
		return productid;
	}

	public void setProductid(String productid) {
		this.productid = productid;
	}

	public String getAnimal() {
		return animal;
	}

	public void setAnimal(String animal) {
		this.animal = animal;
	}

	public Map<String, Item> getItemMap() {
		return itemMap;
	}

	public void setItemMap(Map<String, Item> itemMap) {
		this.itemMap = itemMap;
	}

	public String getItemid() {
		return itemid;
	}

	public void setItemid(String itemid) {
		this.itemid = itemid;
	}

	public String getAttr() {
		return attr;
	}

	public void setAttr(String attr) {
		this.attr = attr;
	}

	public String getAttr1() {
		return attr1;
	}

	public void setAttr1(String attr1) {
		this.attr1 = attr1;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public List<Category> getCategorylist() {
		return categorylist;
	}

	public void setCategorylist(List<Category> categorylist) {
		this.categorylist = categorylist;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public List<Views> getViewlist() {
		return viewlist;
	}

	public void setViewlist(List<Views> viewlist) {
		this.viewlist = viewlist;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Double getListPrice() {
		return listPrice;
	}

	public void setListPrice(Double listPrice) {
		this.listPrice = listPrice;
	}

}
