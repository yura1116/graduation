package com.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.domain.Cart;
import com.domain.Item;
import com.domain.Product;
import com.service.CartService;
import com.service.CategoryService;

public class CartAction {

	private Item item;
	private List<Item> itemlist;
	
	private int first;
	
	private Product product;
	private List<Product> productlist;
	
	private String itemid;
	private String attr;
	private String attr1;
	private Double price;
	private String quantity;
	private String cartQty;
	
	private Map<String, Item> itemMap;
	
	private Cart cart;
	private List<Cart> cartlist;
	
	private int  index;
	private Double s;
	
	private int begin;
	private Long qty;
	
	
	public String queryCart(){
		
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		//��¼�˲�ѯ���ﳵ
	
		System.out.println("uid : " + session.getAttribute("uid"));	
		String userid = (String) session.getAttribute("uid");
		
		cart = new Cart();
		CartService cs = new CartService();	
		CategoryService cas = new CategoryService();	
		
		//��ѯ	
		cart.setUserid(userid);
		cartlist = cs.queryCartByUid(cart);
		itemlist  = new ArrayList<Item>();
		
		System.out.println(cartlist + "123");
		
		for(Cart c : cartlist){
			
			item = new Item();
			item.setItemid(c.getItemid());
			item = cas.queryItemByItemid(item);

			item.setAmount(c.getQuantity());
			Double sprice = item.getListprice()*item.getAmount();
			item.setSprice(sprice);
			
			//����Ʒ��
			product = new Product();
			product.setProductid(item.getProductid());
			product = cas.queryProductById(product);
			
			item.setIname(product.getName());
			
			itemlist.add(item);
			
			s = 0.0;
			for(Item i : itemlist){
				
				s+=i.getSprice();
				System.out.println("�ܽ��" +s);
				
			}	//for
			
		}	//for(cart)	
	
	return "success";
	}	//queryCart
	
	
	public String addCart(){
		
		//������Ʒ  
		
		System.out.println("��Ʒ���: " + itemid);
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		String userid = (String) session.getAttribute("uid");
		System.out.println("uid = " + "��¼������Ʒ" + userid);
		
		//������Ʒ��Ų�ѯ��Ϣ
		CategoryService cs = new CategoryService();
		
		item = new Item();
		item.setItemid(itemid);
		
		item = cs.queryItemByItemid(item);
		
		System.out.println(item.getItemid() + "   " + item.getProductid());
		
		product = new Product();
		product.setProductid(item.getProductid());
		product = cs.queryProductById(product);
		
		System.out.println("�˵�Ʒ�֣� " + product.getName());
		
		item.setIname(product.getName());
		
		item.setAmount((long)1);
		
		Double sprice = item.getListprice()*item.getAmount();
		item.setSprice(sprice);
		
		cart = new Cart();
		
		CartService cs1 = new CartService();	

		cart.setUserid(userid);
		cart.setItemid(item.getItemid())	;
		cart = cs1.queryCart(cart);	//��ѯ
		
		if(cart == null){
				//��Ϊ�� ��
			System.out.println("û�д�����˻��µĸ���Ʒ");
			
			cart = new Cart();
			cart.setUserid(userid);
			cart.setItemid(item.getItemid());
			cart.setQuantity(item.getAmount());
			
			System.out.println(cart.getItemid()+"!!!!!!!!!");
			cs1.saveCart(cart);
			
		}else{	
			//��Ϊ�� ������
			System.out.println("������˻��µĸ���Ʒ");
			System.out.println(cart.getItemid()+"!!!!!!!!!");
				
			cart.setUserid(userid);
			cart.setItemid(cart.getItemid());
			cart = cs1.queryCart(cart);
			
			cart.setId(cart.getId());
			cart.setQuantity(cart.getQuantity()+1);
			
			cs1.updataCart(cart);
			
			
		}	////if(cart)

		//��ѯ	
		cart.setUserid(userid);

		cartlist = cs1.queryCartByUid(cart);
		itemlist  = new ArrayList<Item>();
		
		System.out.println(cartlist + "123");
		
		for(Cart c : cartlist){
			
			item = new Item();
			item.setItemid(c.getItemid());
			item = cs.queryItemByItemid(item);

			item.setAmount(c.getQuantity());
			Double sprice1 = item.getListprice()*item.getAmount();
			item.setSprice(sprice1);
			
			//����Ʒ��
			product = new Product();
			product.setProductid(item.getProductid());
			product = cs.queryProductById(product);
			
			item.setIname(product.getName());
			
		
			itemlist.add(item);
			
			s = 0.0;
			for(Item i : itemlist){
				
				s+=i.getSprice();
				System.out.println("�ܽ��" +s);
				
			}	//for
			
		}	//for(cart)
		
		return "success";	
			
		
	}	//addCart


	public String delCart(){
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
			
		System.out.println("ɾ��" + itemid);
		String userid = (String) session.getAttribute("uid");
		CartService cs = new CartService();
		CategoryService cas = new CategoryService();
		
		cart = new Cart();
		cart.setUserid(userid);
		cart.setItemid(itemid);
		
		cs.delCart(cart);
		
		//��ѯ	
		cart.setUserid(userid);

		cartlist = cs.queryCartByUid(cart);
		itemlist  = new ArrayList<Item>();
		
		System.out.println(cartlist + "123");
		
		for(Cart c : cartlist){
			
			item = new Item();
			item.setItemid(c.getItemid());
			item = cas.queryItemByItemid(item);

			item.setAmount(c.getQuantity());
			Double sprice1 = item.getListprice()*item.getAmount();
			item.setSprice(sprice1);
			
			//����Ʒ��
			product = new Product();
			product.setProductid(item.getProductid());
			product = cas.queryProductById(product);
			
			item.setIname(product.getName());

			itemlist.add(item);
			
			s = 0.0;
			for(Item i : itemlist){
				
				s+=i.getSprice();
				System.out.println("�ܽ��" +s);
				
			}	//for
			
		}	//for(cart)

		return "success";
	}	//delCart
	
	
	public String cartCheckout(){
		
		System.out.println("----------");
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		String userid = (String) session.getAttribute("uid");
		CartService cs = new CartService();
		CategoryService cas = new CategoryService();
		
		//��ѯ
		cart = new Cart();
		itemlist  = new ArrayList<Item>();
		
		cart.setUserid(userid);

		cartlist = cs.queryCartById(cart);
		System.out.println(cartlist + "123");

		for(Cart c : cartlist){
			item = new Item();
			item.setItemid(c.getItemid());
			item = cas.queryItemByItemid(item);

			item.setAmount(c.getQuantity());
			Double sprice = item.getListprice()*item.getAmount();
			item.setSprice(sprice);

			//����Ʒ��
			product = new Product();
			product.setProductid(item.getProductid());
			product = cas.queryProductById(product);
			
			item.setIname(product.getName());
			
			itemlist.add(item);

		}	//cart	

		s = 0.0;
		for(Item i : itemlist){
			
			s+=i.getSprice();
			System.out.println("�ܽ��" +s);
			
		}	//for
	
		session.setAttribute("smoney", s);
		return "success";
			
	}	//cartCheckout
	
	public CartAction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	public List<Item> getItemlist() {
		return itemlist;
	}
	public void setItemlist(List<Item> itemlist) {
		this.itemlist = itemlist;
	}
	public int getFirst() {
		return first;
	}
	public void setFirst(int first) {
		this.first = first;
	}
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public List<Product> getProductlist() {
		return productlist;
	}
	public void setProductlist(List<Product> productlist) {
		this.productlist = productlist;
	}

	public String getItemid() {
		return itemid;
	}

	public void setItemid(String itemid) {
		this.itemid = itemid;
	}

	public String getCartQty() {
		return cartQty;
	}

	public void setCartQty(String cartQty) {
		this.cartQty = cartQty;
	}

	public String getAttr() {
		return attr;
	}

	public void setAttr(String attr) {
		this.attr = attr;
	}

	public String getAttr1() {
		return attr1;
	}

	public void setAttr1(String attr1) {
		this.attr1 = attr1;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public Map<String, Item> getItemMap() {
		return itemMap;
	}

	public void setItemMap(Map<String, Item> itemMap) {
		this.itemMap = itemMap;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public List<Cart> getCartlist() {
		return cartlist;
	}

	public void setCartlist(List<Cart> cartlist) {
		this.cartlist = cartlist;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public Double getS() {
		return s;
	}

	public void setS(Double s) {
		this.s = s;
	}

	public int getBegin() {
		return begin;
	}

	public void setBegin(int begin) {
		this.begin = begin;
	}

	public Long getQty() {
		return qty;
	}

	public void setQty(Long qty) {
		this.qty = qty;
	}
}
