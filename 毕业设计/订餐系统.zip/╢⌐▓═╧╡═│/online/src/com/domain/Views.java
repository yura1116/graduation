package com.domain;

/**
 * Views entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Views implements java.io.Serializable {

	// Fields

	private Long orderid;
	private String userid;
	private String comments;

	// Constructors

	/** default constructor */
	public Views() {
	}

	/** minimal constructor */
	public Views(Long orderid) {
		this.orderid = orderid;
	}

	/** full constructor */
	public Views(Long orderid, String userid, String comments) {
		this.orderid = orderid;
		this.userid = userid;
		this.comments = comments;
	}

	// Property accessors

	public Long getOrderid() {
		return this.orderid;
	}

	public void setOrderid(Long orderid) {
		this.orderid = orderid;
	}

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}