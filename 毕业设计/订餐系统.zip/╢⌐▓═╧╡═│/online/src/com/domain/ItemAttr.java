package com.domain;

public class ItemAttr {
	
	private Item item;
	private Product product;
	private Lineitem lineitem;

	public ItemAttr() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Lineitem getLineitem() {
		return lineitem;
	}
	public void setLineitem(Lineitem lineitem) {
		this.lineitem = lineitem;
	}
	
}
