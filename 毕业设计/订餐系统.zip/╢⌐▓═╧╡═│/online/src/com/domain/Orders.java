package com.domain;


/**
 * Orders entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Orders implements java.io.Serializable {

	// Fields

	private Long orderid;
	private String userid;
	private String orderdate;
	private Double totalprice;
	private String creditcard;
	private String status;
	private String tel;
	private String loc;
	private String sex;
	private String username;
	
	private String orderStatus;
	
	// Constructors

	/** default constructor */
	public Orders() {
	}

	/** minimal constructor */
	public Orders(Long orderid, String userid, String orderdate,
			Double totalprice, String status) {
		this.orderid = orderid;
		this.userid = userid;
		this.orderdate = orderdate;
		this.totalprice = totalprice;
		this.status = status;
	}

	/** full constructor */
	public Orders(Long orderid, String userid, String orderdate,
			Double totalprice, String creditcard, String status, String tel,
			String loc, String sex, String username) {
		this.orderid = orderid;
		this.userid = userid;
		this.orderdate = orderdate;
		this.totalprice = totalprice;
		this.creditcard = creditcard;
		this.status = status;
		this.tel = tel;
		this.loc = loc;
		this.sex = sex;
		this.username = username;
	}

	// Property accessors

	public Long getOrderid() {
		return this.orderid;
	}

	public void setOrderid(Long orderid) {
		this.orderid = orderid;
	}

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}
	
	public String getOrderdate() {
		return orderdate;
	}

	
	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}


	public Double getTotalprice() {
		return this.totalprice;
	}

	public void setTotalprice(Double totalprice) {
		this.totalprice = totalprice;
	}

	public String getCreditcard() {
		return this.creditcard;
	}

	public void setCreditcard(String creditcard) {
		this.creditcard = creditcard;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTel() {
		return this.tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getLoc() {
		return this.loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	
}