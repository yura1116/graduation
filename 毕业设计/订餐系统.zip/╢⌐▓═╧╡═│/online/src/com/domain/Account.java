package com.domain;

/**
 * Account entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Account implements java.io.Serializable {

	// Fields

	private String userid;
	private String email;
	private String status;
	private String phone;

	// Constructors

	/** default constructor */
	public Account() {
	}

	/** minimal constructor */
	public Account(String userid, String email, String phone) {
		this.userid = userid;
		this.email = email;
		this.phone = phone;
	}

	/** full constructor */
	public Account(String userid, String email, String status, String phone) {
		this.userid = userid;
		this.email = email;
		this.status = status;
		this.phone = phone;
	}

	// Property accessors

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}