package com.service;

import java.util.ArrayList;
import java.util.List;

import com.dao.CartDAOFactory;
import com.dao.iface.CartDAOIface;
import com.dao.iface.CategoryDAOIface;
import com.domain.Cart;
import com.service.iface.CartServiceIface;

public class CartService implements CartServiceIface {

	private CartDAOIface cartDAO;
	
	public CartService() {
		super();
		// TODO Auto-generated constructor stub
		cartDAO = CartDAOFactory.createCartDAO();
	}

	public void saveCart(Cart cart) {
		
		cartDAO.saveCart(cart);
	}	//saveCart
	
	public Cart queryCart(Cart cart) {
		String hql = 
			"from Cart" +
			" where userid = ?" +
			" and itemid = ?";
		
		
		return cartDAO.queryCart(hql, cart);
	}	//queryCart
	
	public void updataCart(Cart cart) {
		
		cartDAO.updataCart(cart);
		
	}	//updataCart
	
	public List<Cart> queryCartByUid(Cart cart) {
		
		String hql = 
			"from Cart" +
			" where userid = ?";

		return cartDAO.queryCartByUid(hql, cart);
	}	//queryCartByUid
	
	public void delCart(Cart cart) {
		// TODO Auto-generated method stub
		
		String hql = 
			"delete from Cart" +
			" where userid = ?" +
			" and itemid = ?";
		cartDAO.delCart(hql, cart);
	}

	public void delCartById(Cart cart) {
		
		String hql = 
			"delete from Cart" +
			" where userid = ?";
		cartDAO.delCartById(hql, cart);
		
	}	//delCartById
	
	public List<Cart> queryCartById(Cart cart) {
		String hql = 
			"from Cart" +
			" where userid = ?";

		return cartDAO.queryCartById(hql, cart);
	}	//queryCartById

	public int countCarts(Cart cart) {
		
		String hql = 
			"select count(*)" +
			"from Cart" +
			" where userid = ?";

		return cartDAO.countCarts(hql, cart);
	}	//countCarts

	public static void main(String[] args) {
		
		CartService cs = new CartService();
		
		
	} //main
	
}
