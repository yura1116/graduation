package com.service;

import java.util.ArrayList;
import java.util.List;

import com.dao.CategoryDAOFactory;
import com.dao.iface.CategoryDAOIface;
import com.domain.Category;
import com.domain.Item;
import com.domain.Product;
import com.domain.Views;
import com.service.iface.CategoryServiceIface;

public class CategoryService implements CategoryServiceIface {

	private CategoryDAOIface categoryDAO;

	public CategoryService() {
		super();
		// TODO Auto-generated constructor stub
		categoryDAO = CategoryDAOFactory.createCategoryDAO();
	}

	public Category queryCategoryByName(Category category) {
		String hql = 
			"from Category" +
			" where name = ?";
		
		return categoryDAO.queryCategoryByName(hql, category);
	}	//queryCategoryByName
	
	public List<Item> queryItemById(Item item) {
		String hql = 
			" from Item" +
			" where productid = ?";
		
		return categoryDAO.queryItemById(hql, item);
			
	}	//queryItemById
	
	public List<Product> queryProduct(Product product) {
		String hql = 
			"from Product" +
			" where category like ?";
		return categoryDAO.queryProduct(hql, product);
	}	//queryProduct
	
	public Product queryProductById(Product product) {
		
		String hql = 
			"from Product" +
			" where productid = ?";
		return categoryDAO.queryProductById(hql, product);
		
	}	//queryProductById
	
	public Item queryItemByItemid(Item item) {

		String hql = 
			" from Item" +
			" where itemid = ?";
		
		return categoryDAO.queryItemByItemid(hql, item);
		
	}	//queryItemByItemid

	
	public List<Category> queryCategory() {
		String hql = 
			" from  Category" ;
		
		return categoryDAO.queryCategory(hql);
	}	//queryCategory

	
	public Category queryCategoryByContent(Category category) {
		String hql = 
			"from Category" +
			" where content = ?";
		
		return categoryDAO.queryCategoryByContent(hql, category);
	}	//queryCategoryByContent
	
	@Override
	public void delItemById(Item item) {
		// TODO Auto-generated method stub
		
		String hql = 
				"delete from Item" +
				" where itemid = ?";
		
		categoryDAO.delItemById(hql, item);
		
	}	//delItemById

	
	@Override
	public List<Item> queryItems() {
		// TODO Auto-generated method stub
		String hql = 
				"from Item" ;
			
			return categoryDAO.queryItems(hql);
	}	//queryItems
	
	@Override
	public void saveItems(Item item) {
		// TODO Auto-generated method stub
		
		categoryDAO.saveItems(item);
	}	//saveItems
	
	@Override
	public void updateItemById(Item item) {
		// TODO Auto-generated method stub
		categoryDAO.updateItemById(item);
	}	//updateItemById
	
	@Override
	public List<Views> queryViews() {
		String hql = 
			"from Views" ;
		
		return categoryDAO.queryViews(hql);
	}	//queryViews
	
	public static void main(String[] args) {
		
		CategoryService cs = new CategoryService();
		
		Category cat = new Category();
		
		List<Item> itemlist = new ArrayList<Item>();
		
//		itemlist = cs.queryItems();
//		
//		for(Item i : itemlist){
//			System.out.println(i.getItemid()+"==="+i.getAttr1());
//			
//		}
		
		Item item = new Item();
		//item.setItemid("2222");
		item.setProductid("bl-pd");
		item.setListprice((double)25);
		item.setAttr1("���");
		item.setAttr2("images/hupi.jpg");
		
		cs.saveItems(item);
//		cs.delItemById(item);
		
		cs.updateItemById(item);
		
//		List<Views> viewlist = new ArrayList<Views>();
//		viewlist = cs.queryViews();
//		for(Views v : viewlist){
//			
//			System.out.println(v.getUserid()+v.getOrderid()+v.getComments());
//		}
		
		
	}	//main

	

	

	
}
