package com.service;

import java.util.ArrayList;
import java.util.List;

import com.dao.SignonDAOFactory;
import com.dao.iface.SignonDAOIface;
import com.domain.Account;
import com.domain.Admin;
import com.domain.Signon;
import com.service.iface.SignonServiceIface;

public class SignonService implements SignonServiceIface {

	private SignonDAOIface signondao;
	
	public SignonService() {
		super();
		// TODO Auto-generated constructor stub
		signondao = SignonDAOFactory.createSignonDAO();
	}

	public int countSignons(Signon s) {
		
		String hql = 
			"select count(*) " +
			" from com.domain.Signon" +
			" where userid = ?" +
			" and password = ?";
		return signondao.countSignons(hql, s);
	}	//countSignons
	
	@Override
	public int countAdmins(Admin a) {
		String hql = 
				"select count(*) " +
				" from com.domain.Admin" +
				" where username = ?" +
				" and pwd = ?";
			return signondao.countAdmins(hql, a);
	}	//countAdmins
	
	@Override
	public List<Account> queryAllUsers() {
		String hql = 
				"from Account" ;
			
		return signondao.queryAllUsers(hql);
	}	//queryAllUsers
	public static void main(String[] args) {
		SignonService s = new SignonService();
		Signon signon = new Signon("1","j2ee");
		
		//Admin a = new Admin("sandy","123");
		// int count = s.countAdmins(a);
		// System.out.println(count);
		
		List<Account> acclist = new ArrayList<Account>();
		acclist = s.queryAllUsers();
		
		for(Account a : acclist){
			
			System.out.println(a.getUserid()+"--"+a.getPhone()+"++"+a.getEmail());
		}
		
	}	//main

	
	
}
