package com.service;

import com.dao.RegisterDAOFactory;
import com.dao.iface.RegisterDAOIface;
import com.domain.Account;
import com.domain.Signon;
import com.service.iface.RegisterServiceIface;

public class RegisterService implements RegisterServiceIface {

	private RegisterDAOIface registerdao;
	
	public RegisterService() {
		super();
		// TODO Auto-generated constructor stub
		registerdao = RegisterDAOFactory.createRegisterDAO();
	}

	public int countSignonByUserid(Signon signon) {
		
		String hql = 
			"select count(*) " +
			" from Signon" +
			" where userid = ?";
		
		return registerdao.countSignonByUserid(hql, signon);
	}	//countSignonByUserid
	
	public void saveSignon(Signon signon) {

		registerdao.saveSignon(signon);
		
	}	//saveSignon
	
	public void saveAccount(Account account) {
		
		registerdao.saveAccount(account);
		
	}	//saveAccount

	public Account queryAccountById(Account account) {
		String hql = 
			"from Account" +
			" where userid = ?";
		return registerdao.queryAccountById(hql, account);
		
	}	//queryAccountById
	
	public void updateSignonById(Signon signon) {
		
		 registerdao.updateSignonById(signon);
		
	}	//updateSignonById
	
	public static void main(String[] args) {
		
		RegisterService rs = new RegisterService();
		
	}	//main

}
