package com.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.dao.OrdersDAOFactory;
import com.dao.iface.OrdersDAOIface;
import com.domain.Item;
import com.domain.Lineitem;
import com.domain.LineitemId;
import com.domain.Orders;
import com.domain.Views;
import com.service.iface.OrdersServiceIface;

public class OrdersService implements OrdersServiceIface {

	private OrdersDAOIface orderDAO;

	public OrdersService() {
		super();
		// TODO Auto-generated constructor stub
		orderDAO = OrdersDAOFactory.createOrdersDAO();
	}

	public void saveOrders(Orders order) {
		// TODO Auto-generated method stub
		orderDAO.saveOrders(order);
	}	//saveOrders
	
	public Orders queryOrders(Orders order) {
		
		String hql = 
			"from Orders" +
			" where orderid = ?";
		return orderDAO.queryOrders(hql, order);
	}	//queryOrders
	
	public void saveLineitem(Lineitem lineitem,Orders order,Item item) {
		// TODO Auto-generated method stub
		orderDAO.saveLineitem(lineitem, order, item);
	}	//saveLineitem
	
	public List<Lineitem> queryLineitem(Orders order) {
		
		String hql = 
			"from Lineitem" +
			" where orderid = ?";
		return orderDAO.queryLineitem(hql, order);
	}	//queryLineitem
	
	public List<Orders> queryOrdersById(Orders order) {
		String hql = 
			"from Orders" +
			" where userid = ?" ;
	
		return orderDAO.queryOrdersById(hql, order);
	}	//queryOrdersById
	
	@Override
	public void saveComments(Views view) {
		// TODO Auto-generated method stub
		orderDAO.saveComments(view);
	}	//saveComments
	
	@Override
	public List<Orders> queryOrders() {
		String hql = 
				"from Orders" ;
			
		return orderDAO.queryOrders(hql);
	}	//queryOrders
	
	@Override
	public void updateOrdersById(Orders order) {
		// TODO Auto-generated method stub
		
		orderDAO.updateOrdersById(order);
		
	}	//updateOrdersById
	
	public static void main(String[] args) {
		OrdersService os = new OrdersService();
		
//		List<Orders> orderlist = new ArrayList<Orders>();
//		
//		orderlist = os.queryOrders();
//		
//		for(Orders o : orderlist){
//			
//			System.out.println(o.getOrderid()+o.getOrderdate()+o.getLoc());
//		}
		
		Orders o = new Orders();
		o.setOrderid((long)599);
		
		o.setStatus("����������");
		
		os.updateOrdersById(o);
		
		
	}	//main

	

	
}
