package com.dao;

import com.dao.iface.CategoryDAOIface;

public class CategoryDAOFactory {

	public static CategoryDAOIface createCategoryDAO(){
		
		return new CategoryDAO();
	}
	
}
