package com.dao;
import com.dao.iface.OrdersDAOIface;

public class OrdersDAOFactory {
	
	public static OrdersDAOIface createOrdersDAO(){
		
		return new OrdersDAO();
	}
}
