package com.dao;

import com.dao.iface.CartDAOIface;

public class CartDAOFactory {

	public static CartDAOIface createCartDAO(){
		
		return new CartDAO();
	}
	
}
