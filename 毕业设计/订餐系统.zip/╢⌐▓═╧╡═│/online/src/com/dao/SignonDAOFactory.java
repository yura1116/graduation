package com.dao;

import com.dao.iface.SignonDAOIface;

public class SignonDAOFactory {

	public static SignonDAOIface createSignonDAO(){
		
		return new SignonDAO();
	}
}
