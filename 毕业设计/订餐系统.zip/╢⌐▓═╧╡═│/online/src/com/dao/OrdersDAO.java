package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dao.iface.OrdersDAOIface;
import com.domain.Cart;
import com.domain.Item;
import com.domain.Lineitem;
import com.domain.LineitemId;
import com.domain.Orders;
import com.domain.Views;
import com.hibernate.HibernateSessionFactory;

public class OrdersDAO implements OrdersDAOIface {

	public void saveOrders(Orders order) {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		session.save(order);
		
		tx.commit();
		session.close();
		
	}	//saveOrders

	public Orders queryOrders(String hql, Orders order) {
		Orders o = new Orders();
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, order.getOrderid());

		o = (Orders) query.uniqueResult();
		
		session.close();
		return o;
	}	//queryOrders

	public void saveLineitem(Lineitem lineitem,Orders order,Item item) {
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		LineitemId key = new LineitemId(order.getOrderid(),item.getItemid());
		
		Lineitem line = new Lineitem();
		line.setId(key);
		line.setQuantity(lineitem.getQuantity());
		line.setUnitprice(lineitem.getUnitprice());
		
		session.save(lineitem);
		
		tx.commit();
		session.close();
		
	}	//saveLineitem

	public List<Lineitem> queryLineitem(String hql, Orders order) {
		List<Lineitem> list = new ArrayList<Lineitem>();
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, order.getOrderid());

		list = query.list();
		
		session.close();
		return list;
	}	//queryLineitem

	public List<Orders> queryOrdersById(String hql, Orders order) {
		
		List<Orders> orderlist = new ArrayList<Orders>();
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, order.getUserid());
		
		orderlist = query.list();
		
		session.close();
		return orderlist;
	}	//queryOrdersById

	@Override
	public void saveComments(Views view) {
		// TODO Auto-generated method stub
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		session.save(view);
		
		tx.commit();
		session.close();
		
	}	//saveComments

	@Override
	public List<Orders> queryOrders(String hql) {
		
		List<Orders> orderlist = new ArrayList<Orders>();
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		
		orderlist = query.list();
		
		session.close();
		return orderlist;
		
	}	//queryOrders

	@Override
	public void updateOrdersById(Orders order) {
		// TODO Auto-generated method stub
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		Orders o = (Orders) session.get(Orders.class, order.getOrderid());
		
		o.setStatus(order.getStatus());
		
		session.update(o);
		
		tx.commit();
		session.close();
		
	}	//updateOrdersById

}
