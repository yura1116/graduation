package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dao.iface.CartDAOIface;
import com.domain.Cart;
import com.domain.Product;
import com.domain.Signon;
import com.hibernate.HibernateSessionFactory;

public class CartDAO implements CartDAOIface {

	public void saveCart(Cart cart) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();

		session.save(cart);
		
		tx.commit();
		session.close();

	}	//CartDAO

	public Cart queryCart(String hql, Cart cart) {
		
		Cart c = new Cart();
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, cart.getUserid());
		query.setParameter(1, cart.getItemid());

		c = (Cart) query.uniqueResult();
		
		session.close();
		return c;
	}	//queryCart

	public void updataCart(Cart cart) {

		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		Cart c = (Cart) session.get(Cart.class, cart.getId());

		c.setQuantity(cart.getQuantity());
		
		session.update(c);
		
		tx.commit();
		session.close();

		
	}	//updataCart

	public List<Cart> queryCartByUid(String hql, Cart cart) {
		
		List<Cart> cartlist = new ArrayList<Cart>();
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, cart.getUserid());

		cartlist = query.list();
		
		session.close();
		return cartlist;
	}	//queryCartByUid

	public void delCart(String hql,Cart cart) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, cart.getUserid());
		query.setParameter(1, cart.getItemid());
		
		query.executeUpdate();
		tx.commit();
		session.close();

	}	//delCart

	public void delCartById(String hql, Cart cart) {
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, cart.getUserid());
		
		query.executeUpdate();
		tx.commit();
		session.close();
	}	//delCartById

	public List<Cart> queryCartById(String hql, Cart cart) {
		List<Cart> cartlist = new ArrayList<Cart>();
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, cart.getUserid());
		
		cartlist = query.list();
		
		session.close();
		return cartlist;
	}	//queryCartById

	public int countCarts(String hql, Cart cart) {
		Integer count = 0;
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, cart.getUserid());
		
		
		count = (Integer) query.uniqueResult();
		
		session.close();
		return count;
	}	//countCarts

}
