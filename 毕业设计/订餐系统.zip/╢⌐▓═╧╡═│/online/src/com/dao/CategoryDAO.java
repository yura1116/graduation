package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dao.iface.CategoryDAOIface;
import com.domain.Category;
import com.domain.Item;
import com.domain.Product;
import com.domain.Signon;
import com.domain.Views;
import com.hibernate.HibernateSessionFactory;

public class CategoryDAO implements CategoryDAOIface {

	public Category queryCategoryByName(String hql, Category category) {
		
		Category c = null;
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, category.getName());
		
		c = (Category) query.uniqueResult();
		
		session.close();
		return c;
	}	//queryCategoryByName


	public List<Item> queryItemById(String hql, Item item) {
		
		List<Item> itemlist = new ArrayList<Item>();
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, item.getProductid());

		itemlist = query.list();
		
		session.close();
		return itemlist;
		
	}	//queryItemById

	public List<Product> queryProduct(String hql, Product product) {
		
		List<Product> productlist = new ArrayList<Product>();
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, "%"+product.getCategory()+"%");
		
		productlist = query.list();
		
		session.close();
		return productlist;
	}	//queryProduct

	public Product queryProductById(String hql, Product product) {
		
		Product p = new Product();
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, product.getProductid());
		
		p =  (Product) query.uniqueResult();
		
		session.close();
		
		return p;
	}	//queryProductById

	public Item queryItemByItemid(String hql, Item item) {
		
		Item i = new Item();
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, item.getItemid());
		
		i = (Item) query.uniqueResult();
		
		session.close();
		
		return i;
	}	//queryItemByItemid

	public List<Category> queryCategory(String hql) {
		List<Category> categorylist = new ArrayList<Category>();
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		
		categorylist = query.list();
		
		session.close();
		return categorylist;
	}	//queryCategory
	
	public Category queryCategoryByContent(String hql, Category category) {
		
		Category c = null;
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, category.getContent());
		
		c = (Category) query.uniqueResult();
		
		session.close();
		return c;
	}	//queryCategoryByContent


	@Override
	public List<Item> queryItems(String hql) {
		// TODO Auto-generated method stub
		List<Item> itemlist = new ArrayList<Item>();
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		
		itemlist = query.list();
		
		session.close();
		return itemlist;
		
	}	//queryItems


	@Override
	public void delItemById(String hql, Item item) {
		// TODO Auto-generated method stub
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, item.getItemid());
		
		query.executeUpdate();
		tx.commit();
		session.close();
		
	}	//delItemById


	@Override
	public void saveItems(Item item) {
		// TODO Auto-generated method stub
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		session.save(item);
		
		tx.commit();
		session.close();
		
		
	}	//saveItems


	@Override
	public void updateItemById(Item item) {
		// TODO Auto-generated method stub
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		Item ite = (Item) session.get(Item.class, item.getItemid());
		
		ite.setListprice(item.getListprice());
		ite.setAttr1(item.getAttr1());
		
		session.update(ite);
		
		tx.commit();
		session.close();
		
	}	//updateItemById


	@Override
	public List<Views> queryViews(String hql) {
		
		List<Views> viewlist = new ArrayList<Views>();
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		
		viewlist = query.list();
		
		session.close();
		return viewlist;
	}	//queryViews

}
