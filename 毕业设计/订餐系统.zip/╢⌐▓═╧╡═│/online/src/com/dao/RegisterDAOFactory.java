package com.dao;

import com.dao.iface.RegisterDAOIface;

public class RegisterDAOFactory {

	public static  RegisterDAOIface createRegisterDAO(){
		
		return new RegisterDAO();
		
	}	
}
