package com.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dao.iface.RegisterDAOIface;
import com.domain.Account;
import com.domain.Signon;
import com.hibernate.HibernateSessionFactory;

public class RegisterDAO implements RegisterDAOIface {

	public int countSignonByUserid(String hql,Signon signon) {
		
		Integer count = 0;
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, signon.getUserid());
		
		count = (Integer) query.uniqueResult();
		
		session.close();
		
		return count;
		
	}	//countSignonByUserid
	
	public void saveSignon(Signon signon) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		Signon sig = new Signon(signon.getUserid(),signon.getPassword());
		
		session.save(sig);
		
		tx.commit();
		session.close();
		
		
	}	//saveSignon

	
	
	public void saveAccount(Account acc) {

		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		Account account = new Account(acc.getUserid(),acc.getEmail(),acc.getStatus(),
				acc.getPhone());
		
		session.save(account);
		
		tx.commit();
		session.close();
		
	}	//saveAccount


	public Account queryAccountById(String hql, Account account) {

		Account acc = null;
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0,account.getUserid());
		
		acc = (Account) query.uniqueResult();
		
		session.close();
		
		return acc;
		
	}	//queryAccountById
	
	public void updateSignonById(Signon signon) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		Signon sig = (Signon) session.get(Signon.class, signon.getUserid());
		
		sig.setPassword(signon.getPassword());
		
		session.update(sig);
		
		tx.commit();
		session.close();
		
	}	//updateSignonById

}
