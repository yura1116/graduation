package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.dao.iface.SignonDAOIface;
import com.domain.Account;
import com.domain.Admin;
import com.domain.Lineitem;
import com.domain.Signon;
import com.hibernate.HibernateSessionFactory;

public class SignonDAO implements SignonDAOIface {

	public int countSignons(String hql, Signon s) {
		
		Integer count = 0;
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, s.getUserid());
		query.setParameter(1, s.getPassword());
		
		count = (Integer) query.uniqueResult();
		
		session.close();
		
		return count;
	}	//countSignons

	@Override
	public int countAdmins(String hql, Admin a) {
		Integer count = 0;
		
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);
		query.setParameter(0, a.getUsername());
		query.setParameter(1, a.getPwd());
		
		count = (Integer) query.uniqueResult();
		
		session.close();
		
		return count;
	}	//countAdmins

	@Override
	public List<Account> queryAllUsers(String hql) {
		List<Account> list = new ArrayList<Account>();
		Session session = HibernateSessionFactory.getSession();
		
		Query query = session.createQuery(hql);

		list = query.list();
		
		session.close();
		
		return list;
	}	//queryAllUsers
	
}
